<?php
include 'barcode128.php';
echo bar128('8981 6553 4733');
?>